// Kiểm tra xem trang này có được mở bởi Extension không
chrome.storage.local.get(['targetScore', 'isAutoGrading'], function (data) {
    if (data.isAutoGrading && data.targetScore) {
        console.log("Auto Grading Started for Score: " + data.targetScore);
        autoFillAndSave(data.targetScore);
    }
});

function safeSendMessage(message, callback) {
    if (chrome.runtime?.id) {
        chrome.runtime.sendMessage(message, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Gửi tin nhắn thất bại:", chrome.runtime.lastError.message);
            }
            if (callback) callback(response);
        });
    } else {
        console.error("Extension context invalid. Không thể gửi tin nhắn:", message);
    }
}

function autoFillAndSave(score) {
    // 1. Điền điểm vào tất cả các ô có id bắt đầu bằng txtScore_
    const inputs = document.querySelectorAll('input[id^="txtScore_"]');

    if (inputs.length === 0) {
        // Có thể trang chưa load xong hoặc không có input
        return;
    }

    inputs.forEach(input => {
        input.value = score;
        // Kích hoạt sự kiện để JS của trang web tính toán lại (calculateTotalScore)
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        input.dispatchEvent(new Event('blur', { bubbles: true })); // Trigger blur để format số và bỏ viền đỏ
    });

    // 2. Yêu cầu Background override window.confirm
    safeSendMessage({ action: "OVERRIDE_DIALOGS" }, (response) => {
        console.log("--> [Content] Dialog override response:", response);

        // 3. Bấm nút Lưu sau khi đã override (hoặc đợi 1 chút)
        setTimeout(() => {
            // Tìm nút lưu
            const saveBtn = document.querySelector('button[onclick="SaveAllScore()"]');
            if (saveBtn) {
                console.log("--> [Content] Sắp click Save...");
                saveBtn.click();

                // Gửi thông báo về background là đã xong nhiệm vụ
                setTimeout(() => {
                    safeSendMessage({ action: "GRADE_SUBMITTED" });
                }, 600);
            } else {
                console.error("Không tìm thấy nút Lưu");
                safeSendMessage({ action: "GRADE_ERROR", message: "No Save Button" });
            }
        }, 600); // Đợi 1s
    });
}