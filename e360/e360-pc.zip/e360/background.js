console.log("--> [Background] Service Worker đã khởi động!");

// Các biến trạng thái trong RAM (sẽ mất khi SW ngủ hoặc reload extension)
let queue = [];
let currentIndex = 0;
let processingTabId = null;
let isProcessing = false;
const FAIL_SAFE_TIMEOUT = 15000; // 15 giây
let failSafeTimer = null;

// 1. Khởi tạo: Load trạng thái từ Storage để phục hồi nếu bị crash/refresh
chrome.storage.local.get(['bg_queue', 'bg_currentIndex', 'bg_processingTabId', 'bg_isProcessing'], (data) => {
    if (data.bg_isProcessing) {
        console.log("--> [Background] Phát hiện phiên làm việc cũ chưa xong. Khôi phục...");
        queue = data.bg_queue || [];
        currentIndex = data.bg_currentIndex || 0;
        processingTabId = data.bg_processingTabId || null;
        isProcessing = true;

        // Nếu đang dở dang, tiếp tục process
        if (queue.length > 0 && currentIndex < queue.length) {
            // Kiểm tra tab cũ còn sống không, nếu không thì mở tab mới cho index hiện tại
            if (processingTabId) {
                chrome.tabs.get(processingTabId, (tab) => {
                    if (chrome.runtime.lastError || !tab) {
                        console.log("--> [Background] Tab cũ đã mất. Mở lại tab cho SV hiện tại.");
                        processNextStudent(); // Mở lại tab cho SV hiện tại
                    } else {
                        console.log("--> [Background] Tab cũ vẫn còn. Đợi tín hiệu từ tab đó.");
                        // Không làm gì cả, đợi content_grade gửi message "GRADE_SUBMITTED"
                    }
                });
            } else {
                processNextStudent();
            }
        } else {
            console.log("--> [Background] Queue đã hết hoặc rỗng. Reset.");
            resetState();
        }
    }
});

// Hàm lưu trạng thái hiện tại vào Storage
function saveState() {
    chrome.storage.local.set({
        bg_queue: queue,
        bg_currentIndex: currentIndex,
        bg_processingTabId: processingTabId,
        bg_isProcessing: isProcessing
    });
}

// Hàm reset trạng thái
function resetState() {
    queue = [];
    currentIndex = 0;
    processingTabId = null;
    isProcessing = false;
    chrome.storage.local.remove(['bg_queue', 'bg_currentIndex', 'bg_processingTabId', 'bg_isProcessing']);
}

// 2. Lắng nghe tin nhắn
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("--> [Background] Nhận tin nhắn:", request.action);

    // BẮT ĐẦU QUY TRÌNH MỚI
    if (request.action === "START_PROCESS") {
        queue = request.students || [];
        currentIndex = 0;
        isProcessing = true;
        processingTabId = null;

        console.log(`--> [Background] Bắt đầu xử lý ${queue.length} sinh viên.`);
        saveState(); // Lưu ngay

        if (queue.length > 0) {
            processNextStudent();
        }
        sendResponse({ success: true });
    }

    // ĐÃ XONG MỘT SINH VIÊN
    if (request.action === "GRADE_SUBMITTED") {
        console.log("--> [Background] Tab nhập xong. Đóng tab oldId=", processingTabId);

        // Cập nhật UI (xanh)
        if (queue[currentIndex]) {
            sendMessageToTabs({
                action: "UPDATE_STATUS",
                studentId: queue[currentIndex].id,
                status: "done"
            });
        }

        // Đóng tab cũ
        if (processingTabId) {
            chrome.tabs.remove(processingTabId, () => {
                // Ignore error nếu tab đã đóng
                if (chrome.runtime.lastError) { }
            });
        }

        // Tăng index
        currentIndex++;
        processingTabId = null;
        saveState();

        // Clear timeout
        if (failSafeTimer) clearTimeout(failSafeTimer);

        // Tiếp tục
        processNextStudent();
    }

    // GẶP LỖI
    if (request.action === "GRADE_ERROR") {
        console.error("--> [Background] Lỗi tại tab nhập điểm:", request.message);

        if (queue[currentIndex]) {
            sendMessageToTabs({
                action: "UPDATE_STATUS",
                studentId: queue[currentIndex].id,
                status: "error"
            });
        }

        if (processingTabId) {
            chrome.tabs.remove(processingTabId, () => { });
        }

        currentIndex++;
        processingTabId = null;
        saveState();

        // Clear timeout
        if (failSafeTimer) clearTimeout(failSafeTimer);

        processNextStudent();
    }

    // YÊU CẦU OVERRIDE DIALOG
    if (request.action === "OVERRIDE_DIALOGS") {
        console.log("--> [Background] Injecting override script into tab:", sender.tab.id);
        chrome.scripting.executeScript({
            target: { tabId: sender.tab.id, allFrames: true },
            world: 'MAIN',
            func: () => {
                window.confirm = function () { console.log('--> [Auto] Confirm suppressed'); return true; };
                window.alert = function (msg) { console.log('--> [Auto] Alert suppressed:', msg); return true; };
                console.log("--> [Auto] Dialogs Overridden in MAIN world");
            }
        }, () => {
            console.log("--> [Background] Override script injected.");
            sendResponse({ success: true });
        });
        return true; // Keep channel open for sendResponse
    }
});

// Hàm mở tab cho sinh viên tiếp theo
function processNextStudent() {
    if (currentIndex >= queue.length) {
        console.log("--> [Background] Đã xong toàn bộ danh sách.");
        sendMessageToTabs({ action: "ALL_DONE" });
        resetState();
        if (failSafeTimer) clearTimeout(failSafeTimer);
        resetState();
        return;
    }

    const student = queue[currentIndex];
    console.log(`--> [Background] Đang xử lý SV [${currentIndex + 1}/${queue.length}]: ${student.name}`);

    // Set data cho content script đọc
    chrome.storage.local.set({
        targetScore: student.score,
        isAutoGrading: true
    }, function () {
        const url = `https://e360.poly.edu.vn/Proctor/InputScore?sssID=${student.id}`;

        // Thông báo UI đang chạy (cam)
        sendMessageToTabs({
            action: "UPDATE_STATUS",
            studentId: student.id,
            status: "processing"
        });

        // Mở tab mới (active: false để chạy ngầm)
        chrome.tabs.create({ url: url, active: false }, (tab) => {
            processingTabId = tab.id;
            saveState(); // Cập nhật ID tab mới vào storage
            console.log("--> [Background] Đã mở tab ID (Background):", tab.id);

            // Kích hoạt Fail-safe timer
            if (failSafeTimer) clearTimeout(failSafeTimer);
            failSafeTimer = setTimeout(() => {
                console.warn(`--> [Background] Fail-safe Triggered! Tab ${tab.id} quá lâu không phản hồi.`);

                // Báo lỗi về UI
                sendMessageToTabs({
                    action: "UPDATE_STATUS",
                    studentId: student.id,
                    status: "error" // Hoặc 'skip'
                });

                // Đóng tab treo
                chrome.tabs.remove(tab.id, () => { if (chrome.runtime.lastError) { } });

                // Next
                currentIndex++;
                processingTabId = null;
                saveState();
                processNextStudent();
            }, FAIL_SAFE_TIMEOUT);
        });
    });
}

// Hàm gửi tin nhắn (bọc try-catch để tránh lỗi extension context invalidated)
function sendMessageToTabs(msg) {
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            try {
                chrome.tabs.sendMessage(tab.id, msg).catch(() => {
                    // Tab này có thể không phải là checkin page hoặc chưa load xong script
                });
            } catch (e) { }
        });
    });
}