// content-attendance.js
// Mục tiêu: Bóc tách dữ liệu lớp học, điểm danh vắng mặt và thông tin liên lạc (SĐT, Email) từ trang FAP/Poly.
// File này được tiêm ngầm thông qua chrome.scripting.executeScript nên phải return trực tiếp data.

(function extractAttendanceData() {
    console.log("V2 Extractor: Bắt đầu lấy dữ liệu Lớp học, Điểm danh & Liên lạc...");

    // 1. Lấy thông tin lớp học cơ bản
    let class_name = "";
    let course_code = "";
    let course_name = "";
    let class_id = window.location.href.split('/').pop().split('?')[0];

    // Chiến lược A: Quét toàn bộ các bảng thông tin / thẻ tr (hỗ trợ cả th và td, đa cặp nhãn-giá trị)
    const allInfoRows = document.querySelectorAll('table tr, .kt-section table tr, .portlet table tr, .card table tr');
    allInfoRows.forEach(row => {
        const cells = Array.from(row.querySelectorAll('th, td'));
        if (cells.length >= 2) {
            for (let i = 0; i < cells.length - 1; i++) {
                const label = cells[i].innerText.trim();
                const value = cells[i + 1].innerText.trim();

                if (!class_name && /tên\s*(?:lớp|class)|mã\s*lớp/i.test(label) && value) {
                    class_name = value;
                }
                if (!course_code && /mã\s*(?:môn|học\s*phần|subject|course)/i.test(label) && value) {
                    course_code = value;
                }
                if (!course_name && /tên\s*(?:môn|học\s*phần|subject|course)|môn\s*học/i.test(label) && value) {
                    course_name = value;
                }
            }
        }
    });

    // Chiến lược B: Quét tiêu đề trang, breadcrumb, headings nếu bảng thông tin chưa cung cấp đủ
    if (!class_name || !course_code) {
        const headingElements = document.querySelectorAll('h1, h2, h3, h4, .page-title, .kt-portlet__head-title, .breadcrumb, title, .card-title');
        headingElements.forEach(el => {
            const text = el.innerText.trim();
            if (!course_code) {
                // Nhận diện mã môn dạng: CRO101, CRO101 (CRO101), WEB2055, MOB2041...
                const matchCourse = text.match(/\b([A-Z]{2,6}[0-9]{2,5}(?:\s*\([A-Z0-9_.]+\))?)\b/);
                if (matchCourse) course_code = matchCourse[1];
            }
            if (!class_name) {
                // Nhận diện mã lớp dạng: MD21101, WD21202, SA21301, PRO2201.Hienlv12, MOB2041.01...
                const matchClass = text.match(/\b([A-Z]{2,4}[0-9]{5}(?:\.[0-9A-Za-z]+)?|[A-Z]{2,6}[0-9]{2,5}\.[0-9A-Za-z]+)\b/);
                if (matchClass) class_name = matchClass[1];
            }
        });
    }

    // Thiết lập fallback nếu hoàn toàn không tìm thấy
    if (!class_name) class_name = "Unknown Class";
    if (!course_code) course_code = "Unknown Course";
    if (!course_name) course_name = course_code !== "Unknown Course" ? course_code : "Unknown Course Name";

    // Lấy học kỳ nếu có dropdown
    let semester = '';
    const termSelect = document.getElementById('term_id') || document.querySelector('select[name="term_id"]');
    if (termSelect) {
        const selectedOption = termSelect.querySelector('option[selected="selected"]') || termSelect.options[termSelect.selectedIndex];
        if (selectedOption) {
            semester = selectedOption.innerText.replace(/\s+/g, ' ').trim();
        }
    }

    // 2. Tìm các bảng (Info Table & Attendance Table)
    const tables = document.querySelectorAll('table.table');
    let infoTable = null;
    let attendanceTable = null;

    tables.forEach(table => {
        const thead = table.querySelector('thead');
        if (!thead) return;
        const thText = thead.innerText;
        if (thText.includes('Email') && thText.includes('Số điện thoại')) {
            infoTable = table;
        }
        if (thText.includes('Tổng') && thText.includes('Vắng(%)')) {
            attendanceTable = table;
        }
    });

    // 3. Trích xuất thông tin liên lạc (Email, Phone) từ Info Table
    const contactMap = {};
    if (infoTable) {
        const rows = infoTable.querySelectorAll('tbody tr');
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            if (cells.length >= 5) {
                const student_id = cells[1].innerText.trim();
                const name = cells[2].innerText.trim();
                const email = cells[3] ? cells[3].innerText.trim() : '';
                const phone = cells[4] ? cells[4].innerText.trim() : '';
                if (student_id) {
                    contactMap[student_id] = { name, email, phone };
                }
            }
        });
    }

    // 4. Trích xuất bảng điểm danh (Attendance Table)
    if (!attendanceTable) {
        console.warn("V2 Extractor: Không tìm thấy bảng điểm danh.");
        return null;
    }

    const students = [];
    const rows = attendanceTable.querySelectorAll('tbody tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 4) {
            const student_id = cells[1].innerText.trim();
            const name = cells[2].innerText.trim();

            // Cột Tổng (ví dụ: "3/17") -> Lấy số 3
            const totalText = cells[cells.length - 2].innerText.trim();
            const total_absences = parseInt(totalText.split('/')[0]) || 0;

            const contact = contactMap[student_id] || {};

            students.push({
                student_id: student_id,
                name: name || contact.name || '',
                email: contact.email || '',
                phone: contact.phone || '',
                total_absences: total_absences
            });
        }
    });

    // Trả về thẳng cho kết quả của executeScript
    return {
        action: 'upsert-attendance',
        payload: {
            class_info: {
                class_id: class_id,
                class_name: class_name,
                course_code: course_code,
                course_name: course_name,
                semester: semester
            },
            students: students
        }
    };
})();
