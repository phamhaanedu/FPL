// content-attendance.js
// Mục tiêu: Bóc tách dữ liệu lớp học, điểm danh vắng mặt và thông tin liên lạc (SĐT, Email) từ trang FAP/Poly.
// File này được tiêm ngầm thông qua chrome.scripting.executeScript nên phải return trực tiếp data.

(function extractAttendanceData() {
    console.log("V2 Extractor: Bắt đầu lấy dữ liệu Lớp học, Điểm danh & Liên lạc...");

    // 1. Lấy thông tin lớp học cơ bản
    let class_name = "Unknown Class";
    let course_code = "Unknown Course";
    let course_name = "Unknown Course Name";
    let class_id = window.location.href.split('/').pop().split('?')[0];

    const infoRows = document.querySelectorAll('.kt-section table tr');
    infoRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length === 2) {
            const label = cells[0].innerText.trim();
            const value = cells[1].innerText.trim();
            if (label.includes('Tên Lớp')) class_name = value;
            if (label.includes('Mã Môn')) course_code = value;
            if (label.includes('Tên Môn')) course_name = value;
        }
    });

    // Lấy học kỳ nếu có dropdown
    let semester = '';
    const termSelect = document.getElementById('term_id') || document.querySelector('select[name="term_id"]');
    if (termSelect) {
        const selectedOption = termSelect.querySelector('option[selected="selected"]') || termSelect.options[termSelect.selectedIndex];
        if (selectedOption) {
            semester = selectedOption.innerText.replace(/\s+/g, ' ').trim();
        }
    }

    // 2. Tìm các bảng (Info Table & Attendance Table)
    const tables = document.querySelectorAll('table.table');
    let infoTable = null;
    let attendanceTable = null;

    tables.forEach(table => {
        const thead = table.querySelector('thead');
        if (!thead) return;
        const thText = thead.innerText;
        if (thText.includes('Email') && thText.includes('Số điện thoại')) {
            infoTable = table;
        }
        if (thText.includes('Tổng') && thText.includes('Vắng(%)')) {
            attendanceTable = table;
        }
    });

    // 3. Trích xuất thông tin liên lạc (Email, Phone) từ Info Table
    const contactMap = {};
    if (infoTable) {
        const rows = infoTable.querySelectorAll('tbody tr');
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            if (cells.length >= 5) {
                const student_id = cells[1].innerText.trim();
                const name = cells[2].innerText.trim();
                const email = cells[3] ? cells[3].innerText.trim() : '';
                const phone = cells[4] ? cells[4].innerText.trim() : '';
                if (student_id) {
                    contactMap[student_id] = { name, email, phone };
                }
            }
        });
    }

    // 4. Trích xuất bảng điểm danh (Attendance Table)
    if (!attendanceTable) {
        console.warn("V2 Extractor: Không tìm thấy bảng điểm danh.");
        return null;
    }

    const students = [];
    const rows = attendanceTable.querySelectorAll('tbody tr');

    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 4) {
            const student_id = cells[1].innerText.trim();
            const name = cells[2].innerText.trim();

            // Cột Tổng (ví dụ: "3/17") -> Lấy số 3
            const totalText = cells[cells.length - 2].innerText.trim();
            const total_absences = parseInt(totalText.split('/')[0]) || 0;

            const contact = contactMap[student_id] || {};

            students.push({
                student_id: student_id,
                name: name || contact.name || '',
                email: contact.email || '',
                phone: contact.phone || '',
                total_absences: total_absences
            });
        }
    });

    // Trả về thẳng cho kết quả của executeScript
    return {
        action: 'upsert-attendance',
        payload: {
            class_info: {
                class_id: class_id,
                class_name: class_name,
                course_code: course_code,
                course_name: course_name,
                semester: semester
            },
            students: students
        }
    };
})();
