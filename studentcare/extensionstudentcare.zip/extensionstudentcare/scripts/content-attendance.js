﻿// content-attendance.js
// Bóc tách dữ liệu lớp học, điểm danh vắng mặt và thông tin liên hệ (SĐT, Email) từ trang FAP/Poly.
// File này được tiêm ngầm thông qua chrome.scripting.executeScript nên trả về trực tiếp kết quả.

(function extractAttendanceData() {
    console.log("[Content Attendance V2.1] Bắt đầu quét dữ liệu lớp học & điểm danh...");

    // 1. Trích xuất thông tin định danh lớp học cơ bản
    let class_name = "";
    let course_code = "";
    let course_name = "";
    let class_id = window.location.href.split('/').pop().split('?')[0];

    // Quét toàn bộ bảng thông tin lớp hoặc các thẻ tiêu đề (h1..h4, breadcrumbs, portlet...)
    const allInfoRows = document.querySelectorAll('table tr, .kt-section table tr, .portlet table tr, .card table tr, .info-table tr');
    allInfoRows.forEach(row => {
        const cells = Array.from(row.querySelectorAll('th, td'));
        if (cells.length >= 2) {
            for (let i = 0; i < cells.length - 1; i++) {
                const label = (cells[i].innerText || cells[i].textContent || '').trim();
                const value = (cells[i + 1].innerText || cells[i + 1].textContent || '').trim();

                if (!class_name && /tên\s*(?:lớp|class)|mã\s*lớp/i.test(label) && value) {
                    class_name = value;
                }
                if (!course_code && /mã\s*(?:môn|học\s*phần|subject|course)/i.test(label) && value) {
                    course_code = value;
                }
                if (!course_name && /tên\s*(?:môn|học\s*phần|subject|course)|môn\s*học/i.test(label) && value) {
                    course_name = value;
                }
            }
        }
    });

    // Fallback: Quét tiêu đề trang và headings nếu bảng thông tin chưa cung cấp đủ
    if (!class_name || !course_code) {
        const headingElements = document.querySelectorAll('h1, h2, h3, h4, .page-title, .kt-portlet__head-title, .breadcrumb, title, .card-title, .kt-subheader__title');
        headingElements.forEach(el => {
            const text = (el.innerText || el.textContent || '').trim();
            if (!course_code) {
                const matchCourse = text.match(/\b([A-Z]{2,6}[0-9]{2,5}(?:\s*\([A-Z0-9_.]+\))?)\b/);
                if (matchCourse) course_code = matchCourse[1];
            }
            if (!class_name) {
                const matchClass = text.match(/\b([A-Z]{2,4}[0-9]{5}(?:\.[0-9A-Za-z]+)?|[A-Z]{2,6}[0-9]{2,5}\.[0-9A-Za-z]+)\b/);
                if (matchClass) class_name = matchClass[1];
            }
        });
    }

    if (!class_name) class_name = "Unknown Class";
    if (!course_code) course_code = "Unknown Course";
    if (!course_name) course_name = course_code !== "Unknown Course" ? course_code : "Unknown Course Name";

    // Lấy học kỳ nếu có dropdown
    let semester = '';
    const termSelect = document.getElementById('term_id') || document.querySelector('select[name="term_id"]');
    if (termSelect) {
        const selectedOption = termSelect.querySelector('option[selected="selected"]') || termSelect.options[termSelect.selectedIndex];
        if (selectedOption) {
            semester = (selectedOption.innerText || selectedOption.textContent || '').replace(/\s+/g, ' ').trim();
        }
    }

    // 2. Tìm kiếm và phân tích toàn bộ các bảng trên trang (Hỗ trợ cả 1 bảng hợp nhất hoặc 2 bảng phân tách)
    const tables = Array.from(document.querySelectorAll('table'));
    const contactMap = {};
    const studentsList = [];
    const seenStudentIds = new Set();

    console.log(`[Content Attendance V2.1] Tìm thấy ${tables.length} bảng trên trang.`);

    // Regex nhận diện Mã Sinh Viên chuẩn (Ví dụ: PH12345, PS23456, PK34567, PC12345, v.v.)
    const STUDENT_ID_REGEX = /\b([A-Z]{2,4}[0-9]{4,6})\b/i;
    const EMAIL_REGEX = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
    const PHONE_REGEX = /^(?:0|\+84)[0-9]{9,10}$/;

    // Bước 1: Quét thông tin liên hệ từ mọi bảng có chứa Email / SĐT
    tables.forEach(table => {
        const allRows = Array.from(table.querySelectorAll('tr'));
        allRows.forEach(row => {
            const cells = Array.from(row.querySelectorAll('td, th'));
            if (cells.length < 3) return;

            let sId = '';
            let sName = '';
            let sEmail = '';
            let sPhone = '';

            cells.forEach((cell, idx) => {
                const text = (cell.innerText || cell.textContent || '').trim();
                
                // Tìm MSSV
                if (!sId) {
                    const match = text.match(STUDENT_ID_REGEX);
                    if (match && text.length <= 12) {
                        sId = match[1].toUpperCase();
                        // Thường tên sinh viên nằm ngay ô kế tiếp
                        if (cells[idx + 1]) {
                            const nextText = (cells[idx + 1].innerText || cells[idx + 1].textContent || '').trim();
                            if (nextText && !nextText.includes('@') && !/^[0-9+]+$/.test(nextText)) {
                                sName = nextText;
                            }
                        }
                    }
                }

                // Tìm Email
                if (!sEmail && (EMAIL_REGEX.test(text) || text.includes('@fpt.edu.vn') || text.includes('@fe.edu.vn'))) {
                    sEmail = text;
                }

                // Tìm Phone
                if (!sPhone && (PHONE_REGEX.test(text.replace(/[\s.-]/g, '')) || /^(?:0|\+84)[0-9]{8,11}$/.test(text.replace(/[\s.-]/g, '')))) {
                    sPhone = text.replace(/[\s.-]/g, '');
                }
            });

            if (sId) {
                if (!contactMap[sId]) contactMap[sId] = {};
                if (sName && !contactMap[sId].name) contactMap[sId].name = sName;
                if (sEmail && !contactMap[sId].email) contactMap[sId].email = sEmail;
                if (sPhone && !contactMap[sId].phone) contactMap[sId].phone = sPhone;
            }
        });
    });

    console.log(`[Content Attendance V2.1] Đã quét được ${Object.keys(contactMap).length} liên hệ sinh viên.`);

    // Bước 2: Quét bảng điểm danh vắng mặt
    tables.forEach(table => {
        const allRows = Array.from(table.querySelectorAll('tr'));
        if (allRows.length === 0) return;

        // Xác định vị trí cột Tổng vắng / Tỷ lệ vắng động
        let colIndexTotal = -1;
        let colIndexId = -1;
        let colIndexName = -1;

        // Tìm từ hàng tiêu đề (thead hoặc dòng đầu tiên)
        const headerCells = Array.from(allRows[0].querySelectorAll('th, td'));
        headerCells.forEach((th, idx) => {
            const hText = (th.innerText || th.textContent || '').toLowerCase().trim();
            if (/mã\s*(?:sinh\s*viên|sv|học\s*viên)|student\s*code|mssv/i.test(hText)) colIndexId = idx;
            else if (/họ\s*(?:và\s*)?tên|tên\s*sinh\s*viên|student\s*name/i.test(hText)) colIndexName = idx;
            else if (/tổng|vắng|nghỉ|absent/i.test(hText)) colIndexTotal = idx;
        });

        // Quét từng hàng sinh viên trong bảng
        allRows.forEach((row, rowIdx) => {
            if (rowIdx === 0 && headerCells.length > 0 && /mã\s*sv|họ\s*tên|stt/i.test(row.innerText)) return; // Bỏ qua header

            const cells = Array.from(row.querySelectorAll('td'));
            if (cells.length < 3) return;

            let studentId = '';
            let studentName = '';
            let totalAbsences = 0;
            let foundAbsenceScore = false;

            // 1. Nhận diện MSSV
            if (colIndexId >= 0 && cells[colIndexId]) {
                const txt = (cells[colIndexId].innerText || cells[colIndexId].textContent || '').trim();
                const m = txt.match(STUDENT_ID_REGEX);
                if (m) studentId = m[1].toUpperCase();
            }
            if (!studentId) {
                // Quét qua các ô td đầu tiên (ô 0 đến 3) để tìm MSSV
                for (let i = 0; i < Math.min(cells.length, 4); i++) {
                    const txt = (cells[i].innerText || cells[i].textContent || '').trim();
                    const m = txt.match(STUDENT_ID_REGEX);
                    if (m && txt.length <= 12) {
                        studentId = m[1].toUpperCase();
                        if (cells[i + 1] && !studentName) {
                            studentName = (cells[i + 1].innerText || cells[i + 1].textContent || '').trim();
                        }
                        break;
                    }
                }
            }

            if (!studentId) return; // Không phải dòng sinh viên

            // 2. Nhận diện Tên
            if (!studentName && colIndexName >= 0 && cells[colIndexName]) {
                studentName = (cells[colIndexName].innerText || cells[colIndexName].textContent || '').trim();
            }
            if (!studentName && contactMap[studentId]?.name) {
                studentName = contactMap[studentId].name;
            }

            // 3. Nhận diện Số buổi vắng (total_absences)
            // Cách A: Nếu tìm thấy cột Total
            if (colIndexTotal >= 0 && cells[colIndexTotal]) {
                const totalText = (cells[colIndexTotal].innerText || cells[colIndexTotal].textContent || '').trim();
                const num = parseInt(totalText.split('/')[0], 10);
                if (!isNaN(num)) {
                    totalAbsences = num;
                    foundAbsenceScore = true;
                }
            }

            // Cách B: Quét từ các cột cuối bảng ngược lên tìm định dạng "X/Y" (VD: "3/17", "0/15")
            if (!foundAbsenceScore) {
                for (let j = cells.length - 1; j >= Math.max(0, cells.length - 5); j--) {
                    const cellText = (cells[j].innerText || cells[j].textContent || '').trim();
                    if (/^\d+\s*\/\s*\d+$/.test(cellText)) {
                        totalAbsences = parseInt(cellText.split('/')[0], 10) || 0;
                        foundAbsenceScore = true;
                        break;
                    }
                }
            }

            // Cách C: Nếu không có dạng "X/Y", kiểm tra ô áp chót hoặc ô cuối có chứa số nguyên
            if (!foundAbsenceScore && cells.length >= 4) {
                const penultText = (cells[cells.length - 2].innerText || cells[cells.length - 2].textContent || '').trim();
                if (/^\d+$/.test(penultText)) {
                    totalAbsences = parseInt(penultText, 10) || 0;
                    foundAbsenceScore = true;
                }
            }

            // Cách D: Fallback đếm số ô điểm danh bị đánh dấu Vắng (V / Absent / Không phép / Nghỉ)
            if (!foundAbsenceScore) {
                let vCount = 0;
                cells.forEach(cell => {
                    const t = (cell.innerText || cell.textContent || '').trim().toLowerCase();
                    if (t === 'v' || t === 'vắng' || t === 'absent' || t === 'nghỉ') {
                        vCount++;
                    }
                });
                totalAbsences = vCount;
            }

            // Lấy SĐT và Email từ contactMap
            const contact = contactMap[studentId] || {};
            const email = contact.email || '';
            const phone = contact.phone || '';

            if (!seenStudentIds.has(studentId)) {
                seenStudentIds.add(studentId);
                studentsList.push({
                    student_id: studentId,
                    name: studentName || contact.name || '',
                    email: email,
                    phone: phone,
                    total_absences: totalAbsences
                });
            }
        });
    });

    console.log(`[Content Attendance V2.1] ✅ Hoàn tất trích xuất lớp ${class_name} (${course_code}): Tìm thấy ${studentsList.length} sinh viên.`);

    if (studentsList.length === 0) {
        console.warn(`[Content Attendance V2.1] ⚠️ Cảnh báo: Không tìm thấy sinh viên nào trên trang ${window.location.href}`);
    }

    return {
        action: 'upsert-attendance',
        payload: {
            class_info: {
                class_id: class_id,
                class_name: class_name,
                course_code: course_code,
                course_name: course_name,
                semester: semester
            },
            students: studentsList
        }
    };
})();