// content-transcript.js
// Bóc tách bảng điểm, danh sách nợ môn và học kỳ từng môn từ trang: https://gv.poly.edu.vn/student/view_transcript_detail_student?student_code=...

(function extractTranscriptData() {
    console.log("V2 Extractor: Bắt đầu lấy dữ liệu Transcript...");

    const urlParams = new URLSearchParams(window.location.search);
    const student_id = urlParams.get('student_code') || window.location.href.split('student_code=').pop().split('&')[0];

    const transcript = {};
    const transcript_terms = {};
    const debts = [];
    let studentName = '';
    let studentPhone = '';
    let studentEmail = '';

    // 1. Quét thông tin cá nhân (Họ tên, SĐT, Email)
    const allTrs = document.querySelectorAll('tr');
    allTrs.forEach(r => {
        const text = r.innerText;
        if (text.includes('Họ và tên') || text.includes('Họ tên')) {
            const cells = r.querySelectorAll('td, th');
            if (cells.length >= 2) studentName = cells[1].innerText.trim();
        }
        if (text.includes('Điện thoại') || text.includes('Số điện thoại') || text.includes('SĐT')) {
            const cells = r.querySelectorAll('td, th');
            if (cells.length >= 2) studentPhone = cells[1].innerText.trim();
        }
        if (text.includes('Email') || text.includes('Hòm thư')) {
            const cells = r.querySelectorAll('td, th');
            if (cells.length >= 2) studentEmail = cells[1].innerText.trim();
        }
    });

    // Danh sách từ khóa học kỳ để tránh nhầm với mã môn
    const IGNORE_CODES = ['FALL', 'SPRING', 'SUMMER', 'SUMMER2024', 'FALL2024', 'SPRING2025', 'SUMMER2025', 'FALL2025', 'SPRING2026', 'SUMMER2026', 'KY1', 'KY2', 'KY3', 'KY4', 'KY5', 'KY6', 'KY7'];

    // 2. Quét mọi hàng tr trên toàn bộ trang
    allTrs.forEach(row => {
        const cells = Array.from(row.querySelectorAll('td, th'));
        if (cells.length >= 4) {
            let courseCode = '';
            let statusText = '';
            let gradeLetter = '';
            let score10 = '';
            let semesterTerm = '';

            cells.forEach(cell => {
                const txt = cell.innerText.trim();
                const upper = txt.toUpperCase();
                const lower = txt.toLowerCase();

                // A. Nhận diện học kỳ (VD: Fall 2025, Summer 2024, Spring 2026...)
                if (!semesterTerm && /^(Spring|Summer|Fall)\s+\d{4}$/i.test(txt)) {
                    semesterTerm = txt;
                }

                // B. Nhận diện mã môn (VD: GAM108, COM1071, ENT1128, VIE103, NET101...)
                if (!courseCode && /^[A-Z]{2,6}[0-9]{2,5}[A-Za-z0-9_.]*$/.test(txt) && txt.length <= 15) {
                    if (!IGNORE_CODES.includes(upper)) {
                        courseCode = txt;
                    }
                }

                // C. Nhận diện trạng thái chính xác: "Đạt", "Chưa đạt", "Chưa học", "Đang học"
                if (lower === 'chưa đạt' || lower === 'không đạt' || lower === 'học lại' || lower === 'failed' || lower === 'trượt' || lower === 'hỏng') {
                    statusText = 'Chưa đạt';
                } else if (lower === 'chưa học' || lower === 'not started') {
                    statusText = 'Chưa học';
                } else if (lower === 'đang học' || lower === 'studying') {
                    statusText = 'Đang học';
                } else if (lower === 'đạt' || lower === 'passed' || lower === 'pass' || lower === 'miễn') {
                    statusText = 'Đạt';
                }

                // D. Nhận diện điểm chữ
                if (/^(A\+|A|B\+|B|C\+|C|D\+|D|F)$/i.test(txt)) {
                    gradeLetter = upper;
                }

                // E. Nhận diện điểm số thang 10
                if (/^[0-9]+(\.[0-9]+)?$/.test(txt) && parseFloat(txt) <= 10) {
                    score10 = txt;
                }
            });

            // Nếu hàng này chứa một mã môn học hợp lệ
            if (courseCode) {
                let finalStatus = statusText;
                if (!finalStatus) {
                    if (gradeLetter === 'F') finalStatus = 'Chưa đạt';
                    else if (gradeLetter) finalStatus = 'Đạt';
                    else finalStatus = 'Chưa học';
                }

                transcript[courseCode] = finalStatus;
                if (semesterTerm) {
                    transcript_terms[courseCode] = semesterTerm;
                }

                // ⚠️ CHỈ CÓ "Chưa đạt" (hoặc Điểm chữ "F") MỚI LÀ MÔN NỢ!
                const isDebt = finalStatus === 'Chưa đạt' || gradeLetter === 'F';

                if (isDebt && finalStatus !== 'Chưa học' && finalStatus !== 'Đang học' && finalStatus !== 'Đạt') {
                    if (!debts.includes(courseCode)) {
                        debts.push(courseCode);
                    }
                }
            }
        }
    });

    console.log("V2 Extractor Kết quả bóc tách chuẩn:", {
        student_id: student_id,
        total_courses: Object.keys(transcript).length,
        debts: debts,
        transcript_terms: transcript_terms
    });

    return {
        student_id: student_id,
        name: studentName,
        phone: studentPhone,
        email: studentEmail,
        transcript: transcript,
        transcript_terms: transcript_terms,
        debts: debts
    };
})();
