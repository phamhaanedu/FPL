﻿// background.js - V2.1 Service Worker & Offscreen Orchestrator

const GAS_API_URL = "https://script.google.com/macros/s/AKfycbzBbQwZRPIQO0uthJg68G0KnBmwTN316fS7jwPen-EvK3raueFplhoklEwnXKpbosLbZg/exec";
const SECRET_KEY = "a";

// 1. Quản lý vòng đời của Offscreen Document (Manifest V3)
let creatingOffscreenDocument = null;

async function ensureOffscreenDocument() {
    const offscreenUrl = 'offscreen.html';

    // Kiểm tra nếu tài liệu offscreen đã tồn tại
    if (chrome.offscreen && typeof chrome.offscreen.hasDocument === 'function') {
        const hasDoc = await chrome.offscreen.hasDocument();
        if (hasDoc) return;
    } else if (chrome.runtime.getContexts) {
        const existingContexts = await chrome.runtime.getContexts({
            contextTypes: ['OFFSCREEN_DOCUMENT'],
            documentUrls: [chrome.runtime.getURL(offscreenUrl)]
        });
        if (existingContexts.length > 0) return;
    }

    // Tạo mới tài liệu offscreen nếu chưa có
    if (creatingOffscreenDocument) {
        await creatingOffscreenDocument;
    } else {
        creatingOffscreenDocument = chrome.offscreen.createDocument({
            url: offscreenUrl,
            reasons: ['DOM_SCRAPING'],
            justification: 'Cào dữ liệu nợ môn học sinh viên tốc độ cao chạy ngầm'
        });
        await creatingOffscreenDocument;
        creatingOffscreenDocument = null;
        console.log("[Background V2.1] Đã khởi tạo Offscreen Document thành công.");
        // Chờ 250ms để offscreen.js hoàn tất đăng ký onMessage listener
        await new Promise(r => setTimeout(r, 250));
    }
}

async function closeOffscreenDocument() {
    try {
        if (chrome.offscreen && typeof chrome.offscreen.hasDocument === 'function') {
            const hasDoc = await chrome.offscreen.hasDocument();
            if (hasDoc) {
                await chrome.offscreen.closeDocument();
                console.log("[Background V2.1] Đã giải phóng Offscreen Document.");
            }
        }
    } catch (e) {
        console.warn("[Background V2.1] Lỗi khi đóng Offscreen Document:", e);
    }
}

// 2. Gửi dữ liệu tới GAS bằng Fetch POST
async function pushDataToGAS(action, payload) {
    if (!payload || (Array.isArray(payload) && payload.length === 0)) {
        return { success: false, msg: "Empty payload" };
    }

    try {
        console.log(`[Background V2.1] Đẩy payload lên GAS (Action: ${action})...`, payload);

        const response = await fetch(GAS_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'text/plain;charset=utf-8'
            },
            body: JSON.stringify({
                secret_key: SECRET_KEY,
                action: action,
                payload: payload
            })
        });

        const result = await response.json();
        console.log("[Background V2.1] GAS Response:", result);
        return result;
    } catch (e) {
        console.error("[Background V2.1] Lỗi khi gọi GAS API:", e);
        return { success: false, error: e.message };
    }
}

// 3. Lắng nghe thông điệp từ Popup và Offscreen
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    // Gửi trực tiếp 1 payload lên GAS
    if (request.command === "push_to_gas") {
        pushDataToGAS(request.data.action, request.data.payload)
            .then(result => {
                sendResponse({ status: "done", result });
            })
            .catch(err => {
                sendResponse({ status: "error", error: err.message });
            });
        return true;
    }

    // Khởi động cào Transcript (Admin Only) qua Offscreen Document Engine
    if (request.command === "start_transcript_crawl") {
        const { student_ids, semester, force_recrawl } = request;

        (async () => {
            try {
                // Đảm bảo Offscreen Document đang hoạt động
                await ensureOffscreenDocument();

                // Chuyển tiếp công việc sang cho Offscreen Document xử lý
                chrome.runtime.sendMessage({
                    target: 'offscreen',
                    command: 'crawl_transcripts',
                    student_ids: student_ids,
                    semester: semester,
                    force_recrawl: force_recrawl
                }).catch(err => {
                    console.error("[Background V2.1] Không gửi được lệnh tới Offscreen:", err);
                });

            } catch (err) {
                console.error("[Background V2.1] Lỗi khởi động Offscreen:", err);
                chrome.runtime.sendMessage({
                    action: "transcript_error",
                    error: err.message
                }).catch(() => {});
            }
        })();

        sendResponse({ status: "processing", total: (student_ids || []).length });
        return true;
    }

    // Khi cào transcript hoàn tất hoặc lỗi, giải phóng Offscreen Document
    if (request.action === "transcript_completed" || request.action === "transcript_error") {
        setTimeout(() => {
            closeOffscreenDocument();
        }, 1000);
        return false;
    }

    // Khởi động cào Bulk Lớp học (Teacher - Attendance)
    if (request.command === "start_bulk_scraping") {
        const { classes, semester, teacher_id } = request;
        processClassUrls(classes, semester, teacher_id)
            .then(stats => console.log('[Background V2.1] Bulk scraping completed:', stats))
            .catch(e => console.error(e));

        sendResponse({ status: 'started' });
        return true;
    }
});

// 4. Cơ chế duyệt qua từng lớp học ngầm (Background Tabs dành cho Điểm danh)
async function processClassUrls(classes, semester, teacher_id) {
    let savedClassesCount = 0;
    let failedClassesCount = 0;
    let totalSavedStudents = 0;

    console.log(`[Background V2.1] Bắt đầu quét ${classes.length} lớp học (Kỳ: ${semester}, GV: ${teacher_id})...`);

    for (let i = 0; i < classes.length; i++) {
        const classInfo = classes[i];
        const url = classInfo.url;

        // Báo cáo tiến độ về cho Popup
        chrome.runtime.sendMessage({
            action: 'scraping_progress',
            current: i + 1,
            total: classes.length,
            savedClasses: savedClassesCount,
            failedClasses: failedClassesCount,
            savedStudents: totalSavedStudents
        }).catch(() => { });

        let tab = null;
        try {
            // Mở tab ẩn
            tab = await chrome.tabs.create({ url: url, active: false });

            // Chờ tab load DOM
            await new Promise(resolve => setTimeout(resolve, 3500));

            // Bắn script lấy điểm danh (hàm IIFE trả về dữ liệu trực tiếp)
            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['scripts/content-attendance.js']
            });

            if (results && results[0] && results[0].result) {
                const payloadData = results[0].result;

                if (payloadData && payloadData.payload) {
                    const cInfo = payloadData.payload.class_info || {};
                    const students = payloadData.payload.students || [];

                    if (students.length === 0) {
                        console.warn(`[Background V2.1] ⚠️ Lớp ${url} không có sinh viên nào.`);
                        failedClassesCount++;
                    } else {
                        cInfo.semester = semester || cInfo.semester || 'Current';
                        cInfo.teacher_id = teacher_id || '';

                        // Cơ chế Two-way Fallback giữa trang chi tiết điểm danh và trang danh sách my_class
                        if (!cInfo.course_code || cInfo.course_code === "Unknown Course") {
                            if (classInfo.course_code && classInfo.course_code !== "Unknown Course") {
                                cInfo.course_code = classInfo.course_code;
                            }
                        }
                        if (!cInfo.class_name || cInfo.class_name === "Unknown Class") {
                            if (classInfo.class_name && classInfo.class_name !== "Unknown Class") {
                                cInfo.class_name = classInfo.class_name;
                            }
                        }
                        if (!cInfo.course_name || cInfo.course_name === "Unknown Course Name" || cInfo.course_name === "Unknown Course") {
                            if (classInfo.course_name && classInfo.course_name !== "Unknown Course Name") {
                                cInfo.course_name = classInfo.course_name;
                            } else if (cInfo.course_code && cInfo.course_code !== "Unknown Course") {
                                cInfo.course_name = cInfo.course_code;
                            }
                        }

                        if (classInfo.start_date) cInfo.start_date = classInfo.start_date;
                        if (classInfo.end_date) cInfo.end_date = classInfo.end_date;
                        if (classInfo.date_range) cInfo.date_range = classInfo.date_range;
                        if (classInfo.block) cInfo.block = classInfo.block;
                        if (classInfo.class_status) cInfo.class_status = classInfo.class_status;

                        students.forEach(student => {
                            student.teacher_id = teacher_id || '';
                            student.semester = cInfo.semester;
                            student.course_code = cInfo.course_code;
                            student.course_name = cInfo.course_name;
                            student.class_id = cInfo.class_id;
                            student.class_name = cInfo.class_name;
                            student.start_date = cInfo.start_date || '';
                            student.end_date = cInfo.end_date || '';
                            student.date_range = cInfo.date_range || '';
                            student.block = cInfo.block || 'Block 1';
                            student.class_status = cInfo.class_status || 'Ongoing';
                        });

                        // Gửi lên GAS
                        const gasRes = await pushDataToGAS(payloadData.action, payloadData.payload);
                        if (gasRes && (gasRes.status === 200 || gasRes.success !== false)) {
                            savedClassesCount++;
                            totalSavedStudents += students.length;
                            console.log(`[Background V2.1] ✅ Đã lưu thành công lớp ${cInfo.class_name} (${students.length} SV) vào Firestore.`);
                        } else {
                            failedClassesCount++;
                            console.error(`[Background V2.1] ❌ Lỗi GAS khi lưu lớp ${cInfo.class_name}:`, gasRes);
                        }
                    }
                } else {
                    failedClassesCount++;
                }
            } else {
                console.warn(`[Background V2.1] ⚠️ Script trả về null cho URL: ${url}`);
                failedClassesCount++;
            }
        } catch (error) {
            failedClassesCount++;
            console.error(`[Background V2.1] Lỗi trích xuất ${url}:`, error);
        } finally {
            if (tab && tab.id) {
                try {
                    await chrome.tabs.remove(tab.id);
                } catch (e) { }
            }
        }
    }

    // Hoàn tất và gửi thống kê chi tiết về cho Popup
    chrome.runtime.sendMessage({
        action: 'scraping_completed',
        totalClasses: classes.length,
        savedClasses: savedClassesCount,
        failedClasses: failedClassesCount,
        savedStudents: totalSavedStudents
    }).catch(() => { });

    return {
        totalClasses: classes.length,
        savedClasses: savedClassesCount,
        failedClasses: failedClassesCount,
        savedStudents: totalSavedStudents
    };
}