// background.js

const GAS_API_URL = "https://script.google.com/macros/s/AKfycbzBbQwZRPIQO0uthJg68G0KnBmwTN316fS7jwPen-EvK3raueFplhoklEwnXKpbosLbZg/exec";
// Web App URL của GAS
const SECRET_KEY = "a";

// 1. Gửi dữ liệu tới GAS bằng fetch POST
async function pushDataToGAS(action, payload) {
    if (!payload || (Array.isArray(payload) && payload.length === 0)) return { success: false, msg: "Empty payload" };

    try {
        console.log(`Đẩy payload lên GAS (Action: ${action})...`, payload);

        const response = await fetch(GAS_API_URL, {
            method: 'POST',
            body: JSON.stringify({
                secret_key: SECRET_KEY,
                action: action,
                payload: payload
            })
        });

        const result = await response.json();
        console.log("GAS Response:", result);
        return result;
    } catch (e) {
        console.error("Lỗi khi gọi GAS API:", e);
        return { success: false, error: e.message };
    }
}

// 2. Lắng nghe thông điệp từ Popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    // Gửi trực tiếp 1 payload lên GAS
    if (request.command === "push_to_gas") {
        pushDataToGAS(request.data.action, request.data.payload)
            .then(result => {
                sendResponse({ status: "done", result });
            })
            .catch(err => {
                sendResponse({ status: "error", error: err.message });
            });
        return true;
    }

    // Khởi động cào Transcript (Admin Only) bằng Background Tabs an toàn
    if (request.command === "start_transcript_crawl") {
        const { student_ids, semester, force_recrawl } = request;
        processTranscriptStudents(student_ids, semester, force_recrawl)
            .then(() => console.log("Hoàn tất cào transcript."))
            .catch(err => console.error("Lỗi cào transcript:", err));

        sendResponse({ status: "processing", total: (student_ids || []).length });
        return true;
    }

    // Khởi động cào Bulk Lớp học (Teacher)
    if (request.command === "start_bulk_scraping") {
        const { classes, semester, teacher_id } = request;
        processClassUrls(classes, semester, teacher_id)
            .then(() => console.log('Bulk scraping completed.'))
            .catch(e => console.error(e));

        sendResponse({ status: 'started' });
        return true;
    }
});

// 3. Cơ chế duyệt qua từng lớp học ngầm (Background Tabs)
async function processClassUrls(classes, semester, teacher_id) {
    for (let i = 0; i < classes.length; i++) {
        const classInfo = classes[i];
        const url = classInfo.url;

        // Báo cáo tiến độ về cho Popup
        chrome.runtime.sendMessage({
            action: 'scraping_progress',
            current: i + 1,
            total: classes.length
        }).catch(() => { });

        // Mở tab ẩn
        let tab = null;
        try {
            tab = await chrome.tabs.create({ url: url, active: false });

            // Chờ DOM load
            await new Promise(resolve => setTimeout(resolve, 4000));

            // Bắn script lấy điểm danh (hàm IIFE trả về dữ liệu trực tiếp)
            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['scripts/content-attendance.js']
            });

            if (results && results[0].result) {
                const payloadData = results[0].result;

                // Tiêm thêm teacher_id, semester, thời gian, block, class_status vào payload
                if (payloadData && payloadData.payload) {
                    const cInfo = payloadData.payload.class_info || {};
                    const students = payloadData.payload.students || [];

                    cInfo.semester = semester;
                    cInfo.teacher_id = teacher_id;

                    // Cơ chế Two-way Fallback giữa trang chi tiết điểm danh và trang danh sách my_class
                    if (!cInfo.course_code || cInfo.course_code === "Unknown Course") {
                        if (classInfo.course_code && classInfo.course_code !== "Unknown Course") {
                            cInfo.course_code = classInfo.course_code;
                        }
                    }
                    if (!cInfo.class_name || cInfo.class_name === "Unknown Class") {
                        if (classInfo.class_name && classInfo.class_name !== "Unknown Class") {
                            cInfo.class_name = classInfo.class_name;
                        }
                    }
                    if (!cInfo.course_name || cInfo.course_name === "Unknown Course Name" || cInfo.course_name === "Unknown Course") {
                        if (classInfo.course_name && classInfo.course_name !== "Unknown Course Name") {
                            cInfo.course_name = classInfo.course_name;
                        } else if (cInfo.course_code && cInfo.course_code !== "Unknown Course") {
                            cInfo.course_name = cInfo.course_code;
                        }
                    }

                    if (classInfo.start_date) cInfo.start_date = classInfo.start_date;
                    if (classInfo.end_date) cInfo.end_date = classInfo.end_date;
                    if (classInfo.date_range) cInfo.date_range = classInfo.date_range;
                    if (classInfo.block) cInfo.block = classInfo.block;
                    if (classInfo.class_status) cInfo.class_status = classInfo.class_status;

                    students.forEach(student => {
                        student.teacher_id = teacher_id;
                        student.semester = semester;
                        student.course_code = cInfo.course_code;
                        student.course_name = cInfo.course_name;
                        student.class_id = cInfo.class_id;
                        student.class_name = cInfo.class_name;
                        student.start_date = cInfo.start_date || '';
                        student.end_date = cInfo.end_date || '';
                        student.date_range = cInfo.date_range || '';
                        student.block = cInfo.block || 'Block 1';
                        student.class_status = cInfo.class_status || 'Ongoing';
                    });

                    // Gửi lên GAS
                    await pushDataToGAS(payloadData.action, payloadData.payload);
                }
            }
        } catch (error) {
            console.error(`Lỗi trích xuất ${url}:`, error);
        } finally {
            // Dọn dẹp đóng tab
            if (tab && tab.id) {
                try {
                    await chrome.tabs.remove(tab.id);
                } catch (e) { }
            }
        }
    }

    // Hoàn tất
    chrome.runtime.sendMessage({
        action: 'scraping_completed'
    }).catch(() => { });
}

// 4. Cơ chế duyệt qua từng sinh viên để cào Transcript (Background Tabs)
async function processTranscriptStudents(studentIds, semester, forceRecrawl) {
    const results = [];
    console.log(`Bắt đầu cào transcript cho ${studentIds.length} sinh viên (Kỳ: ${semester})...`);

    for (let i = 0; i < studentIds.length; i++) {
        const studentId = studentIds[i].trim();
        if (!studentId) continue;

        // Báo cáo tiến độ về cho Popup
        chrome.runtime.sendMessage({
            action: 'transcript_progress',
            current: i + 1,
            total: studentIds.length
        }).catch(() => { });

        const url = `https://gv.poly.edu.vn/student/view_transcript_detail_student?student_code=${studentId}`;
        let tab = null;

        try {
            // Mở tab ẩn với full session cookie của gv.poly.edu.vn
            tab = await chrome.tabs.create({ url: url, active: false });

            // Chờ DOM load và render hoàn tất
            await new Promise(resolve => setTimeout(resolve, 4000));

            // Bắn script lấy transcript trực tiếp từ live DOM (bao gồm cả iframe nếu có)
            const execResults = await chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                files: ['scripts/content-transcript.js']
            });

            if (execResults && execResults.length > 0) {
                // Ưu tiên frame nào trích xuất được bảng điểm
                const validResult = execResults.find(r => r.result && Object.keys(r.result.transcript || {}).length > 0) || execResults[0];
                if (validResult && validResult.result) {
                    const data = validResult.result;
                    console.log(`Đã cào thành công SV ${studentId}:`, data);
                    results.push(data);
                }
            }
        } catch (error) {
            console.error(`Lỗi trích xuất Transcript SV ${studentId}:`, error);
        } finally {
            if (tab && tab.id) {
                try {
                    await chrome.tabs.remove(tab.id);
                } catch (e) { }
            }
        }
    }

    // Đẩy toàn bộ kết quả lên GAS
    if (results.length > 0) {
        await pushDataToGAS('upsert-transcript', {
            semester: semester,
            force_recrawl: forceRecrawl,
            students: results
        });
    }

    // Báo hoàn tất về cho Popup
    chrome.runtime.sendMessage({
        action: 'transcript_completed',
        total: results.length
    }).catch(() => { });
}
