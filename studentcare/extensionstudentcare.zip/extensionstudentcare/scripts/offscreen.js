// offscreen.js

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Chỉ xử lý thông điệp gửi đích danh tới offscreen
    if (message.target !== 'offscreen') return false;

    if (message.command === 'crawl_transcripts') {
        const studentIds = message.student_ids || [];
        const semester = message.semester || '';
        const forceRecrawl = message.force_recrawl || false;
        console.log(`Bắt đầu cào transcript cho ${studentIds.length} sinh viên (Kỳ: ${semester})...`);
        
        // Gửi phản hồi ngay lập tức để popup không bị timeout
        sendResponse({ status: "processing", total: studentIds.length });

        // Chạy tiến trình cào bất đồng bộ
        (async () => {
            try {
                const results = await crawlTranscriptsParallel(studentIds);
                
                // Đẩy payload lên GAS thông qua background
                if (results.length > 0) {
                    await chrome.runtime.sendMessage({
                        command: "push_to_gas",
                        data: {
                            action: "upsert-transcript",
                            payload: {
                                semester: semester,
                                force_recrawl: forceRecrawl,
                                students: results
                            }
                        }
                    });
                }

                // Báo hoàn tất về cho Popup / Background
                chrome.runtime.sendMessage({
                    action: "transcript_completed",
                    total: results.length
                }).catch(() => {});

            } catch (err) {
                console.error("Lỗi trong quá trình cào transcript:", err);
                chrome.runtime.sendMessage({
                    action: "transcript_error",
                    error: err.message
                }).catch(() => {});
            }
        })();

        return true;
    }
    return true;
});

// Hàm cào chéo song song bằng Promise.allSettled()
async function crawlTranscriptsParallel(studentIds) {
    const results = [];
    const BATCH_SIZE = 5;
    
    for (let i = 0; i < studentIds.length; i += BATCH_SIZE) {
        const batch = studentIds.slice(i, i + BATCH_SIZE);
        const promises = batch.map(id => fetchTranscript(id));
        
        const settled = await Promise.allSettled(promises);
        
        settled.forEach((outcome, index) => {
            if (outcome.status === 'fulfilled' && outcome.value) {
                results.push(outcome.value);
            } else {
                console.warn(`Không cào được transcript cho SV ${batch[index]}:`, outcome.reason);
            }
        });

        // Báo cáo tiến độ
        chrome.runtime.sendMessage({
            action: 'transcript_progress',
            current: Math.min(i + BATCH_SIZE, studentIds.length),
            total: studentIds.length
        }).catch(() => {});
    }
    return results;
}

// Cào transcript 1 sinh viên từ trang GV Poly: https://gv.poly.edu.vn/student/student_infomation?student_code=MSSV
async function fetchTranscript(studentId) {
    const cleanId = studentId.trim();
    if (!cleanId) return null;

    const url = `https://gv.poly.edu.vn/student/view_transcript_detail_student?student_code=${cleanId}`;
    
    try {
        console.log(`Đang fetch dữ liệu: ${url}`);
        const response = await fetch(url, { credentials: 'include' });
        if (!response.ok) {
            console.warn(`Lỗi HTTP ${response.status} khi fetch ${url}`);
            return null;
        }
        
        const htmlText = await response.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlText, "text/html");
        
        const transcript = {};
        const debts = [];
        let studentName = '';
        let studentPhone = '';
        let studentEmail = '';

        // 1. Trích xuất thông tin sinh viên từ các table/info boxes
        const allRows = doc.querySelectorAll('tr');
        allRows.forEach(r => {
            const text = r.innerText;
            if (text.includes('Họ và tên') || text.includes('Họ tên')) {
                const cells = r.querySelectorAll('td, th');
                if (cells.length >= 2) studentName = cells[1].innerText.trim();
            }
            if (text.includes('Điện thoại') || text.includes('Số điện thoại') || text.includes('SĐT')) {
                const cells = r.querySelectorAll('td, th');
                if (cells.length >= 2) studentPhone = cells[1].innerText.trim();
            }
            if (text.includes('Email') || text.includes('Hòm thư')) {
                const cells = r.querySelectorAll('td, th');
                if (cells.length >= 2) studentEmail = cells[1].innerText.trim();
            }
        });

        // 2. Trích xuất bảng điểm / tiến độ môn học
        const tables = doc.querySelectorAll('table');
        tables.forEach(table => {
            const rows = table.querySelectorAll('tbody tr, tr');
            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                if (cells.length >= 3) {
                    let courseCode = '';
                    let statusText = '';

                    // Tìm mã môn (3-8 ký tự, ví dụ: GAM106, PRO230, IT101, SKI101...)
                    for (let i = 0; i < cells.length; i++) {
                        const cellText = cells[i].innerText.trim();
                        if (!courseCode && /^[A-Z]{2,5}[0-9]{2,4}[A-Za-z0-9_.]*$/.test(cellText) && cellText.length <= 15) {
                            courseCode = cellText;
                        }
                    }

                    // Nếu tìm thấy mã môn trong hàng
                    if (courseCode) {
                        // Tìm cột trạng thái hoặc lấy cột cuối
                        for (let j = cells.length - 1; j >= 0; j--) {
                            const cText = cells[j].innerText.trim();
                            const cLower = cText.toLowerCase();
                            if (cLower.includes('đạt') || cLower.includes('passed') || cLower.includes('pass') ||
                                cLower.includes('hỏng') || cLower.includes('trượt') || cLower.includes('failed') || cLower.includes('học lại') ||
                                cLower.includes('chưa') || cLower.includes('đang học') || cLower.includes('miễn')) {
                                statusText = cText;
                                break;
                            }
                        }

                        if (!statusText && cells.length >= 4) {
                            statusText = cells[cells.length - 1].innerText.trim();
                        }

                        if (statusText) {
                            transcript[courseCode] = statusText;
                            const stLower = statusText.toLowerCase();
                            if (stLower.includes('fail') || stLower.includes('hỏng') || stLower.includes('trượt') || stLower.includes('học lại') || stLower.includes('không đạt')) {
                                if (!debts.includes(courseCode)) {
                                    debts.push(courseCode);
                                }
                            }
                        }
                    }
                }
            });
        });

        console.log(`Đã trích xuất thành công SV ${cleanId}: ${Object.keys(transcript).length} môn, ${debts.length} nợ môn.`);

        return {
            student_id: cleanId,
            name: studentName,
            phone: studentPhone,
            email: studentEmail,
            transcript: transcript,
            debts: debts
        };
    } catch (e) {
        console.error(`Lỗi fetch ${studentId}:`, e);
        return null;
    }
}
