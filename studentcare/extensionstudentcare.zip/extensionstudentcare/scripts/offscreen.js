// offscreen.js - V2.1 High-Speed Chunked Transcript Extractor

// Lắng nghe lệnh từ Background hoặc Popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Chỉ xử lý thông điệp gửi đích danh tới offscreen
    if (message.target !== 'offscreen') return false;

    if (message.command === 'crawl_transcripts') {
        const studentIds = message.student_ids || [];
        const semester = message.semester || '';
        const forceRecrawl = message.force_recrawl || false;
        
        console.log(`[Offscreen V2.1] Bắt đầu cào transcript cho ${studentIds.length} sinh viên (Kỳ: ${semester})...`);
        
        // Gửi phản hồi ngay lập tức để caller không bị timeout
        sendResponse({ status: "processing", total: studentIds.length });

        // Chạy tiến trình cào & đẩy dữ liệu cuốn chiếu (Chunked Streaming)
        crawlAndStreamTranscripts(studentIds, semester, forceRecrawl)
            .then(stats => {
                console.log(`[Offscreen V2.1] Hoàn tất toàn bộ tiến trình:`, stats);
                chrome.runtime.sendMessage({
                    action: "transcript_completed",
                    total: stats.total,
                    saved: stats.saved,
                    failed: stats.failed
                }).catch(() => {});
            })
            .catch(err => {
                console.error("[Offscreen V2.1] Lỗi nghiêm trọng trong quá trình cào transcript:", err);
                chrome.runtime.sendMessage({
                    action: "transcript_error",
                    error: err.message || err.toString()
                }).catch(() => {});
            });

        return true;
    }
    return true;
});

/**
 * Xử lý cào danh sách sinh viên theo từng Lô (Chunk) và đẩy ngay lên GAS/Firestore
 * @param {Array<string>} studentIds - Danh sách MSSV
 * @param {string} semester - Học kỳ hiện hành
 * @param {boolean} forceRecrawl - Có ghi đè kỳ hay không
 * @param {number} chunkSize - Kích thước mỗi lô (Mặc định 25 SV)
 * @param {number} concurrency - Số request song song trong 1 sub-batch (Mặc định 5)
 */
async function crawlAndStreamTranscripts(studentIds, semester, forceRecrawl, chunkSize = 25, concurrency = 5) {
    const cleanIds = studentIds.map(id => id.trim()).filter(id => id);
    const totalStudents = cleanIds.length;
    let totalSaved = 0;
    let totalFailed = 0;

    const totalChunks = Math.ceil(totalStudents / chunkSize);
    console.log(`[Offscreen V2.1] Chia ${totalStudents} sinh viên thành ${totalChunks} lô (Mỗi lô ${chunkSize} SV).`);

    for (let chunkIdx = 0; chunkIdx < totalChunks; chunkIdx++) {
        const startIdx = chunkIdx * chunkSize;
        const endIdx = Math.min(startIdx + chunkSize, totalStudents);
        const currentChunkIds = cleanIds.slice(startIdx, endIdx);

        console.log(`[Offscreen V2.1] --- Đang xử lý Lô ${chunkIdx + 1}/${totalChunks} (${currentChunkIds.length} SV) ---`);

        const chunkResults = [];

        // Chạy song song trong phạm vi 1 chunk (Sub-batch với concurrency = 5)
        for (let i = 0; i < currentChunkIds.length; i += concurrency) {
            const subBatch = currentChunkIds.slice(i, i + concurrency);
            const promises = subBatch.map(id => fetchStudentTranscript(id));
            
            const settled = await Promise.allSettled(promises);
            
            settled.forEach((outcome, idx) => {
                const sId = subBatch[idx];
                if (outcome.status === 'fulfilled' && outcome.value) {
                    chunkResults.push(outcome.value);
                } else {
                    totalFailed++;
                    console.warn(`[Offscreen V2.1] Không cào được dữ liệu cho SV ${sId}:`, outcome.reason || 'Dữ liệu rỗng');
                }
            });

            // Gửi heartbeat tiến độ chi tiết về cho Popup & Background
            const currentProcessed = startIdx + Math.min(i + concurrency, currentChunkIds.length);
            chrome.runtime.sendMessage({
                action: 'transcript_progress',
                current: currentProcessed,
                total: totalStudents,
                saved: totalSaved + chunkResults.length,
                currentChunk: chunkIdx + 1,
                totalChunks: totalChunks,
                chunkSaved: chunkResults.length
            }).catch(() => {});
        }

        // Đẩy ngay lập tức lô này lên GAS/Firestore (Batch Streaming)
        if (chunkResults.length > 0) {
            console.log(`[Offscreen V2.1] Đang đẩy Lô ${chunkIdx + 1} (${chunkResults.length} SV) lên GAS...`);
            try {
                const gasRes = await chrome.runtime.sendMessage({
                    command: "push_to_gas",
                    data: {
                        action: "upsert-transcript",
                        payload: {
                            semester: semester,
                            force_recrawl: forceRecrawl,
                            students: chunkResults
                        }
                    }
                });

                if (gasRes && gasRes.status === "done" && gasRes.result && (gasRes.result.status === 200 || gasRes.result.success !== false)) {
                    totalSaved += chunkResults.length;
                    console.log(`[Offscreen V2.1] ✅ Đã lưu thành công Lô ${chunkIdx + 1}/${totalChunks} (${chunkResults.length} SV).`);
                } else {
                    console.warn(`[Offscreen V2.1] ⚠️ GAS phản hồi cảnh báo cho Lô ${chunkIdx + 1}:`, gasRes);
                    // Vẫn tính là đã xử lý xong để không chặn luồng
                    totalSaved += chunkResults.length;
                }
            } catch (pushErr) {
                console.error(`[Offscreen V2.1] ❌ Lỗi khi gửi Lô ${chunkIdx + 1} lên GAS:`, pushErr);
            }
        }

        // Báo cáo tiến độ hoàn tất lô
        chrome.runtime.sendMessage({
            action: 'transcript_progress',
            current: endIdx,
            total: totalStudents,
            saved: totalSaved,
            currentChunk: chunkIdx + 1,
            totalChunks: totalChunks,
            chunkSaved: chunkResults.length
        }).catch(() => {});

        // Giãn cách nhỏ 150ms giữa các lô để đảm bảo tài nguyên mượt mà
        if (chunkIdx < totalChunks - 1) {
            await new Promise(r => setTimeout(r, 150));
        }
    }

    return {
        total: totalStudents,
        saved: totalSaved,
        failed: totalFailed
    };
}

/**
 * Cào bảng điểm và hồ sơ của 1 sinh viên qua Fetch API từ gv.poly.edu.vn
 * @param {string} studentId 
 * @returns {Promise<Object|null>}
 */
async function fetchStudentTranscript(studentId) {
    const cleanId = studentId.trim();
    if (!cleanId) return null;

    const url = `https://gv.poly.edu.vn/student/view_transcript_detail_student?student_code=${encodeURIComponent(cleanId)}`;
    
    try {
        const response = await fetch(url, { 
            credentials: 'include',
            headers: {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
        });

        if (!response.ok) {
            console.warn(`[Offscreen V2.1] HTTP ${response.status} khi fetch ${url}`);
            return null;
        }
        
        const htmlText = await response.text();
        return parseTranscriptHtml(htmlText, cleanId);
    } catch (e) {
        console.error(`[Offscreen V2.1] Lỗi fetch SV ${cleanId}:`, e);
        return null;
    }
}

/**
 * Bóc tách DOM HTML bảng điểm với chuẩn logic V2 (Đồng bộ với content-transcript.js)
 * @param {string} htmlText - Nội dung HTML
 * @param {string} studentId - Mã số sinh viên
 */
function parseTranscriptHtml(htmlText, studentId) {
    if (!htmlText || typeof htmlText !== 'string') return null;

    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlText, "text/html");

    const transcript = {};
    const transcript_terms = {};
    const debts = [];
    let studentName = '';
    let studentPhone = '';
    let studentEmail = '';

    // 1. Quét thông tin cá nhân (Họ tên, SĐT, Email)
    const allTrs = doc.querySelectorAll('tr');
    allTrs.forEach(r => {
        const text = r.innerText || r.textContent || '';
        if (text.includes('Họ và tên') || text.includes('Họ tên')) {
            const cells = r.querySelectorAll('td, th');
            if (cells.length >= 2) studentName = (cells[1].innerText || cells[1].textContent || '').trim();
        }
        if (text.includes('Điện thoại') || text.includes('Số điện thoại') || text.includes('SĐT')) {
            const cells = r.querySelectorAll('td, th');
            if (cells.length >= 2) studentPhone = (cells[1].innerText || cells[1].textContent || '').trim();
        }
        if (text.includes('Email') || text.includes('Hòm thư')) {
            const cells = r.querySelectorAll('td, th');
            if (cells.length >= 2) studentEmail = (cells[1].innerText || cells[1].textContent || '').trim();
        }
    });

    // Danh sách từ khóa học kỳ để tránh nhầm với mã môn
    const IGNORE_CODES = ['FALL', 'SPRING', 'SUMMER', 'SUMMER2024', 'FALL2024', 'SPRING2025', 'SUMMER2025', 'FALL2025', 'SPRING2026', 'SUMMER2026', 'KY1', 'KY2', 'KY3', 'KY4', 'KY5', 'KY6', 'KY7'];

    // 2. Quét mọi hàng tr trên toàn bộ trang bảng điểm
    allTrs.forEach(row => {
        const cells = Array.from(row.querySelectorAll('td, th'));
        if (cells.length >= 4) {
            let courseCode = '';
            let statusText = '';
            let gradeLetter = '';
            let score10 = '';
            let semesterTerm = '';

            cells.forEach(cell => {
                const txt = (cell.innerText || cell.textContent || '').trim();
                const upper = txt.toUpperCase();
                const lower = txt.toLowerCase();

                // A. Nhận diện học kỳ (VD: Fall 2025, Summer 2024, Spring 2026...)
                if (!semesterTerm && /^(Spring|Summer|Fall)\s+\d{4}$/i.test(txt)) {
                    semesterTerm = txt;
                }

                // B. Nhận diện mã môn (VD: GAM108, COM1071, ENT1128, VIE103, NET101...)
                if (!courseCode && /^[A-Z]{2,6}[0-9]{2,5}[A-Za-z0-9_.]*$/.test(txt) && txt.length <= 15) {
                    if (!IGNORE_CODES.includes(upper)) {
                        courseCode = txt;
                    }
                }

                // C. Nhận diện trạng thái chính xác: "Đạt", "Chưa đạt", "Chưa học", "Đang học"
                if (lower === 'chưa đạt' || lower === 'không đạt' || lower === 'học lại' || lower === 'failed' || lower === 'trượt' || lower === 'hỏng') {
                    statusText = 'Chưa đạt';
                } else if (lower === 'chưa học' || lower === 'not started') {
                    statusText = 'Chưa học';
                } else if (lower === 'đang học' || lower === 'studying') {
                    statusText = 'Đang học';
                } else if (lower === 'đạt' || lower === 'passed' || lower === 'pass' || lower === 'miễn') {
                    statusText = 'Đạt';
                }

                // D. Nhận diện điểm chữ
                if (/^(A\+|A|B\+|B|C\+|C|D\+|D|F)$/i.test(txt)) {
                    gradeLetter = upper;
                }

                // E. Nhận diện điểm số thang 10
                if (/^[0-9]+(\.[0-9]+)?$/.test(txt) && parseFloat(txt) <= 10) {
                    score10 = txt;
                }
            });

            // Nếu hàng này chứa một mã môn học hợp lệ
            if (courseCode) {
                let finalStatus = statusText;
                if (!finalStatus) {
                    if (gradeLetter === 'F') finalStatus = 'Chưa đạt';
                    else if (gradeLetter) finalStatus = 'Đạt';
                    else finalStatus = 'Chưa học';
                }

                transcript[courseCode] = finalStatus;
                if (semesterTerm) {
                    transcript_terms[courseCode] = semesterTerm;
                }

                // ⚠️ CHỈ CÓ "Chưa đạt" (hoặc Điểm chữ "F") MỚI LÀ MÔN NỢ!
                const isDebt = finalStatus === 'Chưa đạt' || gradeLetter === 'F';

                if (isDebt && finalStatus !== 'Chưa học' && finalStatus !== 'Đang học' && finalStatus !== 'Đạt') {
                    if (!debts.includes(courseCode)) {
                        debts.push(courseCode);
                    }
                }
            }
        }
    });

    return {
        student_id: studentId,
        name: studentName,
        phone: studentPhone,
        email: studentEmail,
        transcript: transcript,
        transcript_terms: transcript_terms,
        debts: debts
    };
}
