// popup.js - V2.1 UI Controller & Live Progress Monitor

document.addEventListener('DOMContentLoaded', () => {
    const statusDiv = document.getElementById('status');
    const loginSection = document.getElementById('loginSection');
    const teacherSection = document.getElementById('teacherSection');
    const adminSection = document.getElementById('adminSection');
    
    const btnGoogleLogin = document.getElementById('btnGoogleLogin');
    const btnLogout = document.getElementById('btnLogout');
    const btnAttendance = document.getElementById('btn-extract-attendance');
    const btnTranscript = document.getElementById('btn-crawl-transcripts');
    const teacherEmailSpan = document.getElementById('teacherEmail');

    const progressContainer = document.getElementById('progress-container');
    const progLabel = document.getElementById('prog-label');
    const progPercent = document.getElementById('prog-percent');
    const progBar = document.getElementById('prog-bar');
    const progDetail = document.getElementById('prog-detail');

    const ADMIN_EMAIL = 'anph21@fpt.edu.vn';
    let currentUserEmail = '';

    // Hàm cập nhật thanh tiến độ trực quan
    function updateProgress(percent, label, detail) {
        if (progressContainer) {
            progressContainer.style.display = 'block';
            const clampedPct = Math.min(100, Math.max(0, Math.round(percent)));
            if (progPercent) progPercent.innerText = `${clampedPct}%`;
            if (progBar) progBar.style.width = `${clampedPct}%`;
            if (progLabel && label) progLabel.innerText = label;
            if (progDetail && detail) progDetail.innerText = detail;
        }
    }

    function hideProgress() {
        if (progressContainer) progressContainer.style.display = 'none';
    }

    // Hàm kiểm tra session hiện tại
    function checkLoginStatus() {
        chrome.storage.local.get(['userEmail'], function(result) {
            if (result.userEmail) {
                setLoggedInUI(result.userEmail);
            } else {
                setLoggedOutUI();
            }
        });
    }

    // Hiển thị UI khi đã đăng nhập
    function setLoggedInUI(email) {
        currentUserEmail = email;
        loginSection.style.display = 'none';
        teacherSection.style.display = 'block';
        teacherEmailSpan.innerText = email;

        if (email === ADMIN_EMAIL) {
            adminSection.style.display = 'block';
        } else {
            adminSection.style.display = 'none';
        }
    }

    // Hiển thị UI khi chưa đăng nhập
    function setLoggedOutUI() {
        currentUserEmail = '';
        loginSection.style.display = 'block';
        teacherSection.style.display = 'none';
        adminSection.style.display = 'none';
        statusDiv.innerText = 'Vui lòng đăng nhập.';
        hideProgress();
    }

    // Xử lý đăng xuất
    btnLogout.addEventListener('click', () => {
        chrome.storage.local.remove(['userEmail'], function() {
            setLoggedOutUI();
        });
    });

    // Xử lý đăng nhập
    btnGoogleLogin.addEventListener('click', () => {
        btnGoogleLogin.innerText = 'Đang xác thực...';
        btnGoogleLogin.disabled = true;

        if (chrome.identity && chrome.identity.getProfileUserInfo) {
            chrome.identity.getProfileUserInfo({ accountStatus: "ANY" }, function(userInfo) {
                if (userInfo && userInfo.email) {
                    chrome.storage.local.set({ userEmail: userInfo.email }, function() {
                        setLoggedInUI(userInfo.email);
                        statusDiv.innerText = 'Đăng nhập thành công!';
                        btnGoogleLogin.innerText = 'Đăng nhập bằng Google Chrome';
                        btnGoogleLogin.disabled = false;
                    });
                } else {
                    statusDiv.innerText = 'Lỗi: Không lấy được Email. Đảm bảo bạn đã đồng bộ Chrome.';
                    btnGoogleLogin.innerText = 'Đăng nhập bằng Google Chrome';
                    btnGoogleLogin.disabled = false;
                }
            });
        } else {
            statusDiv.innerText = 'Lỗi: Không hỗ trợ API Identity.';
            btnGoogleLogin.innerText = 'Đăng nhập bằng Google Chrome';
            btnGoogleLogin.disabled = false;
        }
    });

    // 1. Cào Điểm Danh (Bulk Class Scraping)
    btnAttendance.addEventListener('click', async () => {
        statusDiv.innerText = 'Đang quét link lớp học trên trang hiện tại...';
        btnAttendance.disabled = true;

        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        if (!tab || !tab.url.includes("gv.poly.edu.vn/teacher/my_class")) {
            statusDiv.innerText = 'Lỗi: Vui lòng mở trang "Lớp của tôi" (gv.poly.edu.vn/teacher/my_class) để dùng tính năng này.';
            btnAttendance.disabled = false;
            return;
        }

        try {
            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => {
                    let semester = "Unknown Semester";
                    const termSelect = document.getElementById('term_id');
                    if (termSelect) {
                        const selectedOption = termSelect.querySelector('option[selected="selected"]') || termSelect.options[termSelect.selectedIndex];
                        if (selectedOption) semester = selectedOption.innerText.replace(/\s+/g, ' ').trim();
                    }

                    const classDataList = [];
                    const table = document.querySelector('table.table') || document.querySelector('table');
                    
                    let colIndexCourseName = 1;
                    let colIndexCourseCode = 2;
                    let colIndexClassName = 3;
                    let colIndexDateRange = 4;

                    const thead = table ? table.querySelector('thead') : null;
                    if (thead) {
                        const ths = Array.from(thead.querySelectorAll('th, td'));
                        ths.forEach((th, idx) => {
                            const txt = th.innerText.trim();
                            if (/tên\s*môn|môn\s*học/i.test(txt)) colIndexCourseName = idx;
                            else if (/mã\s*môn|mã\s*học\s*phần/i.test(txt)) colIndexCourseCode = idx;
                            else if (/lớp|tên\s*lớp|class/i.test(txt)) colIndexClassName = idx;
                            else if (/thời\s*gian|ngày/i.test(txt)) colIndexDateRange = idx;
                        });
                    }

                    const rows = document.querySelectorAll('table.table tbody tr, table tbody tr, table tr');
                    rows.forEach(row => {
                        const aTag = Array.from(row.querySelectorAll('a')).find(a => a.href && a.href.includes('/teacher/my_class/view/'));
                        if (aTag) {
                            const cells = Array.from(row.querySelectorAll('td'));
                            if (cells.length === 0) return;

                            let course_name = cells[colIndexCourseName] ? cells[colIndexCourseName].innerText.trim() : "";
                            let course_code = cells[colIndexCourseCode] ? cells[colIndexCourseCode].innerText.trim() : "";
                            let class_name = cells[colIndexClassName] ? cells[colIndexClassName].innerText.trim() : "";
                            let date_range = cells[colIndexDateRange] ? cells[colIndexDateRange].innerText.trim() : "";

                            cells.forEach(cell => {
                                const text = cell.innerText.trim();
                                if (!course_code && /^[A-Z]{2,6}[0-9]{2,5}(\s*\([A-Z0-9_.]+\))?$/.test(text)) {
                                    course_code = text;
                                }
                                if (!class_name && (/^[A-Z]{2,4}[0-9]{5}(\.[0-9A-Za-z]+)?$/i.test(text) || /^[A-Z]{2,6}[0-9]{2,5}\.[0-9A-Za-z]+$/i.test(text))) {
                                    class_name = text;
                                }
                                if (!date_range && /(\d{4}[-/]\d{2}[-/]\d{2}|\d{1,2}[-/]\d{1,2}[-/]\d{4})\s*-\s*(\d{4}[-/]\d{2}[-/]\d{2}|\d{1,2}[-/]\d{1,2}[-/]\d{4})/.test(text)) {
                                    date_range = text;
                                }
                            });

                            if (!course_code) course_code = "Unknown Course";
                            if (!class_name) class_name = "Unknown Class";

                            let start_date = "";
                            let end_date = "";
                            let block = "Block 1";
                            let class_status = "Ongoing";

                            const dateMatch = date_range.match(/(\d{4}[-/]\d{2}[-/]\d{2}|\d{1,2}[-/]\d{1,2}[-/]\d{4})\s*-\s*(\d{4}[-/]\d{2}[-/]\d{2}|\d{1,2}[-/]\d{1,2}[-/]\d{4})/);
                            if (dateMatch) {
                                const parseDate = (dStr) => {
                                    if (/^\d{4}-\d{2}-\d{2}$/.test(dStr)) return dStr;
                                    if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dStr)) {
                                        const [d, m, y] = dStr.split('/');
                                        return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
                                    }
                                    return dStr;
                                };
                                start_date = parseDate(dateMatch[1]);
                                end_date = parseDate(dateMatch[2]);

                                if (start_date && end_date) {
                                    const sDate = new Date(start_date);
                                    const eDate = new Date(end_date);
                                    const diffDays = Math.round((eDate - sDate) / (1000 * 60 * 60 * 24));

                                    if (diffDays > 75) {
                                        block = "Full";
                                    } else {
                                        const startMonth = sDate.getMonth() + 1;
                                        if ([1, 5, 9].includes(startMonth) || (startMonth === 2 && sDate.getDate() < 15)) {
                                            block = "Block 1";
                                        } else if ([3, 7, 11].includes(startMonth) || (startMonth === 6 && sDate.getDate() >= 25)) {
                                            block = "Block 2";
                                        } else {
                                            block = (startMonth % 2 === 1) ? "Block 1" : "Block 2";
                                        }
                                    }

                                    const today = new Date().toISOString().split('T')[0];
                                    if (today < start_date) {
                                        class_status = "Upcoming";
                                    } else if (today > end_date) {
                                        class_status = "Completed";
                                    } else {
                                        class_status = "Ongoing";
                                    }
                                }
                            }

                            classDataList.push({
                                url: aTag.href,
                                course_code: course_code,
                                course_name: course_name,
                                class_name: class_name,
                                date_range: date_range,
                                start_date: start_date,
                                end_date: end_date,
                                block: block,
                                class_status: class_status
                            });
                        }
                    });

                    const uniqueClasses = [];
                    const seenUrls = new Set();
                    classDataList.forEach(item => {
                        if(!seenUrls.has(item.url)) {
                            seenUrls.add(item.url);
                            uniqueClasses.push(item);
                        }
                    });

                    return { classes: uniqueClasses, semester: semester };
                }
            });

            const scriptResult = results[0].result || { classes: [], semester: "Unknown Semester" };
            const classList = scriptResult.classes;

            if (classList.length === 0) {
                statusDiv.innerText = 'Không tìm thấy lớp học nào trên trang này.';
                btnAttendance.disabled = false;
                return;
            }

            statusDiv.innerText = `Đã tìm thấy ${classList.length} lớp (Kỳ: ${scriptResult.semester})...`;
            updateProgress(0, 'Điểm danh:', `Đang chuẩn bị quét ${classList.length} lớp...`);

            chrome.runtime.sendMessage({
                command: "start_bulk_scraping",
                classes: classList,
                semester: scriptResult.semester,
                teacher_id: currentUserEmail.split('@')[0] 
            }, (response) => {
                if (response && response.status === "started") {
                    statusDiv.innerText = `Đang quét ngầm ${classList.length} lớp! Bạn có thể làm việc khác.`;
                } else {
                    statusDiv.innerText = 'Lỗi khởi tạo tiến trình ngầm.';
                    btnAttendance.disabled = false;
                    hideProgress();
                }
            });

        } catch (error) {
            statusDiv.innerText = 'Lỗi quét DOM: ' + error.message;
            btnAttendance.disabled = false;
            hideProgress();
        }
    });

    // 2. Cào Transcript (Offscreen Document Engine V2.1)
    btnTranscript.addEventListener('click', () => {
        const idsText = document.getElementById('txt-student-ids').value;
        const semester = (document.getElementById('inp-transcript-semester').value || '').trim();
        const forceRecrawl = document.getElementById('chk-force-recrawl').checked;

        if (!idsText.trim()) {
            statusDiv.innerText = 'Vui lòng nhập MSSV.';
            return;
        }

        // Tách chuỗi theo dấu phẩy, chấm phẩy hoặc xuống dòng
        const studentIds = idsText
            .split(/[\n,;\s]+/)
            .map(id => id.trim())
            .filter(id => id);

        if (studentIds.length === 0) {
            statusDiv.innerText = 'Danh sách MSSV không hợp lệ.';
            return;
        }

        statusDiv.innerText = `Đang khởi động tiến trình ngầm cho ${studentIds.length} SV (Kỳ: ${semester || 'Không xác định'})...`;
        btnTranscript.disabled = true;
        updateProgress(0, 'Cào nợ môn:', `Đang khởi chạy Offscreen Engine cho ${studentIds.length} SV...`);

        chrome.runtime.sendMessage({
            command: "start_transcript_crawl",
            student_ids: studentIds,
            semester: semester,
            force_recrawl: forceRecrawl
        }, (response) => {
            if (response && response.status === "processing") {
                statusDiv.innerText = `Đang chạy ngầm ${studentIds.length} SV! Bạn có thể yên tâm đóng popup.`;
            } else {
                statusDiv.innerText = 'Lỗi khởi chạy tiến trình ngầm.';
                btnTranscript.disabled = false;
                hideProgress();
            }
        });
    });

    // Lắng nghe cập nhật tiến độ từ background & offscreen
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'scraping_progress') {
            const pct = (request.current / request.total) * 100;
            updateProgress(pct, 'Điểm danh:', `Đang lưu lớp ${request.current}/${request.total}...`);
            statusDiv.innerText = `🔄 Đang lưu dữ liệu lớp ${request.current}/${request.total}`;
        } else if (request.action === 'scraping_completed') {
            hideProgress();
            statusDiv.innerText = `🎉 Đã hoàn tất quét dữ liệu toàn bộ lớp học!`;
            btnAttendance.disabled = false;
        } else if (request.action === 'transcript_progress') {
            const pct = (request.current / request.total) * 100;
            const saved = request.saved || request.current;
            const chunkInfo = request.totalChunks ? ` (Lô ${request.currentChunk}/${request.totalChunks})` : '';
            updateProgress(pct, `Cào nợ môn${chunkInfo}:`, `Đã cào & lưu: ${request.current}/${request.total} SV (Đã lưu ${saved} vào DB)`);
            statusDiv.innerText = `🔄 Đang cào Transcript: ${request.current}/${request.total} SV${chunkInfo}`;
        } else if (request.action === 'transcript_completed') {
            const savedCount = request.saved !== undefined ? request.saved : request.total;
            updateProgress(100, 'Hoàn tất:', `Đã lưu thành công ${savedCount}/${request.total} sinh viên vào Firestore!`);
            statusDiv.innerText = `🎉 Đã hoàn tất cào nợ môn cho ${request.total} sinh viên!`;
            btnTranscript.disabled = false;
        } else if (request.action === 'transcript_error') {
            hideProgress();
            statusDiv.innerText = `⚠️ Lỗi cào transcript: ${request.error}`;
            btnTranscript.disabled = false;
        }
    });

    // Khởi tạo
    checkLoginStatus();
});
