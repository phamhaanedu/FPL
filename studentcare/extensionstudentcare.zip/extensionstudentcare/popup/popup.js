// popup.js

document.addEventListener('DOMContentLoaded', () => {
    const statusDiv = document.getElementById('status');
    const loginSection = document.getElementById('loginSection');
    const teacherSection = document.getElementById('teacherSection');
    const adminSection = document.getElementById('adminSection');
    
    const btnGoogleLogin = document.getElementById('btnGoogleLogin');
    const btnLogout = document.getElementById('btnLogout');
    const btnAttendance = document.getElementById('btn-extract-attendance');
    const btnTranscript = document.getElementById('btn-crawl-transcripts');
    const teacherEmailSpan = document.getElementById('teacherEmail');

    const ADMIN_EMAIL = 'anph21@fpt.edu.vn';
    let currentUserEmail = '';

    // Hàm kiểm tra session hiện tại
    function checkLoginStatus() {
        chrome.storage.local.get(['userEmail'], function(result) {
            if (result.userEmail) {
                setLoggedInUI(result.userEmail);
            } else {
                setLoggedOutUI();
            }
        });
    }

    // Hiển thị UI khi đã đăng nhập
    function setLoggedInUI(email) {
        currentUserEmail = email;
        loginSection.style.display = 'none';
        teacherSection.style.display = 'block';
        teacherEmailSpan.innerText = email;

        if (email === ADMIN_EMAIL) {
            adminSection.style.display = 'block';
        } else {
            adminSection.style.display = 'none';
        }
    }

    // Hiển thị UI khi chưa đăng nhập
    function setLoggedOutUI() {
        currentUserEmail = '';
        loginSection.style.display = 'block';
        teacherSection.style.display = 'none';
        adminSection.style.display = 'none';
        statusDiv.innerText = 'Vui lòng đăng nhập.';
    }

    // Xử lý đăng xuất
    btnLogout.addEventListener('click', () => {
        chrome.storage.local.remove(['userEmail'], function() {
            setLoggedOutUI();
        });
    });

    // Xử lý đăng nhập
    btnGoogleLogin.addEventListener('click', () => {
        btnGoogleLogin.innerText = 'Đang xác thực...';
        btnGoogleLogin.disabled = true;

        if (chrome.identity && chrome.identity.getProfileUserInfo) {
            chrome.identity.getProfileUserInfo({ accountStatus: "ANY" }, function(userInfo) {
                if (userInfo && userInfo.email) {
                    // Lưu email vào storage
                    chrome.storage.local.set({ userEmail: userInfo.email }, function() {
                        setLoggedInUI(userInfo.email);
                        statusDiv.innerText = 'Đăng nhập thành công!';
                        btnGoogleLogin.innerText = 'Đăng nhập bằng Google Chrome';
                        btnGoogleLogin.disabled = false;
                    });
                } else {
                    statusDiv.innerText = 'Lỗi: Không lấy được Email. Đảm bảo bạn đã đồng bộ Chrome.';
                    btnGoogleLogin.innerText = 'Đăng nhập bằng Google Chrome';
                    btnGoogleLogin.disabled = false;
                }
            });
        } else {
            statusDiv.innerText = 'Lỗi: Không hỗ trợ API Identity.';
            btnGoogleLogin.innerText = 'Đăng nhập bằng Google Chrome';
            btnGoogleLogin.disabled = false;
        }
    });

    // 1. Cào Điểm Danh (Bulk Class Scraping)
    btnAttendance.addEventListener('click', async () => {
        statusDiv.innerText = 'Đang quét link lớp học trên trang hiện tại...';
        btnAttendance.disabled = true;

        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        // Kiểm tra xem có đang ở trang my_class không
        if (!tab || !tab.url.includes("gv.poly.edu.vn/teacher/my_class")) {
            statusDiv.innerText = 'Lỗi: Vui lòng mở trang "Lớp của tôi" (gv.poly.edu.vn/teacher/my_class) để dùng tính năng này.';
            btnAttendance.disabled = false;
            return;
        }

        try {
            // Bắn script vào trang hiện tại để trích xuất các link lớp học và thông tin lớp
            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => {
                    // Lấy học kỳ từ dropdown term_id
                    let semester = "Unknown Semester";
                    const termSelect = document.getElementById('term_id');
                    if (termSelect) {
                        const selectedOption = termSelect.querySelector('option[selected="selected"]') || termSelect.options[termSelect.selectedIndex];
                        if (selectedOption) semester = selectedOption.innerText.replace(/\s+/g, ' ').trim();
                    }

                    // Cào danh sách link và thông tin lớp học từ table
                    const classDataList = [];
                    const rows = document.querySelectorAll('table.table tbody tr');
                    rows.forEach(row => {
                        const aTag = Array.from(row.querySelectorAll('a')).find(a => a.href.includes('/teacher/my_class/view/'));
                        if (aTag) {
                            const cells = row.querySelectorAll('td');
                            // FAP Table: Cột 1: Tên môn, Cột 2: Mã môn, Cột 3: Tên lớp, Cột 4: Thời gian
                            const course_name = cells[1] ? cells[1].innerText.trim() : "";
                            const course_code = cells[2] ? cells[2].innerText.trim() : "Unknown Course";
                            const class_name = cells[3] ? cells[3].innerText.trim() : "Unknown Class";
                            const date_range = cells[4] ? cells[4].innerText.trim() : "";

                            let start_date = "";
                            let end_date = "";
                            let block = "Block 1";
                            let class_status = "Ongoing";

                            // Bóc tách ngày bắt đầu - ngày kết thúc
                            const dateMatch = date_range.match(/(\d{4}[-/]\d{2}[-/]\d{2}|\d{1,2}[-/]\d{1,2}[-/]\d{4})\s*-\s*(\d{4}[-/]\d{2}[-/]\d{2}|\d{1,2}[-/]\d{1,2}[-/]\d{4})/);
                            if (dateMatch) {
                                const parseDate = (dStr) => {
                                    if (/^\d{4}-\d{2}-\d{2}$/.test(dStr)) return dStr;
                                    if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dStr)) {
                                        const [d, m, y] = dStr.split('/');
                                        return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
                                    }
                                    return dStr;
                                };
                                start_date = parseDate(dateMatch[1]);
                                end_date = parseDate(dateMatch[2]);

                                if (start_date && end_date) {
                                    const sDate = new Date(start_date);
                                    const eDate = new Date(end_date);
                                    const diffDays = Math.round((eDate - sDate) / (1000 * 60 * 60 * 24));

                                    // Lớp kéo dài > 75 ngày -> Full Semester
                                    if (diffDays > 75) {
                                        block = "Full";
                                    } else {
                                        const startMonth = sDate.getMonth() + 1; // 1 - 12
                                        if ([1, 5, 9].includes(startMonth) || (startMonth === 2 && sDate.getDate() < 15)) {
                                            block = "Block 1";
                                        } else if ([3, 7, 11].includes(startMonth) || (startMonth === 6 && sDate.getDate() >= 25)) {
                                            block = "Block 2";
                                        } else {
                                            block = (startMonth % 2 === 1) ? "Block 1" : "Block 2";
                                        }
                                    }

                                    // Trạng thái theo ngày hôm nay
                                    const today = new Date().toISOString().split('T')[0];
                                    if (today < start_date) {
                                        class_status = "Upcoming";
                                    } else if (today > end_date) {
                                        class_status = "Completed";
                                    } else {
                                        class_status = "Ongoing";
                                    }
                                }
                            }

                            classDataList.push({
                                url: aTag.href,
                                course_code: course_code,
                                course_name: course_name,
                                class_name: class_name,
                                date_range: date_range,
                                start_date: start_date,
                                end_date: end_date,
                                block: block,
                                class_status: class_status
                            });
                        }
                    });

                    // Lọc trùng lặp URL
                    const uniqueClasses = [];
                    const seenUrls = new Set();
                    classDataList.forEach(item => {
                        if(!seenUrls.has(item.url)) {
                            seenUrls.add(item.url);
                            uniqueClasses.push(item);
                        }
                    });

                    return { classes: uniqueClasses, semester: semester };
                }
            });

            const scriptResult = results[0].result || { classes: [], semester: "Unknown Semester" };
            const classList = scriptResult.classes;

            if (classList.length === 0) {
                statusDiv.innerText = 'Không tìm thấy lớp học nào trên trang này.';
                btnAttendance.disabled = false;
                return;
            }

            statusDiv.innerText = `Đã tìm thấy ${classList.length} lớp (Kỳ: ${scriptResult.semester})...`;

            // Gửi danh sách lớp sang background.js để quét từng tab một
            chrome.runtime.sendMessage({
                command: "start_bulk_scraping",
                classes: classList,
                semester: scriptResult.semester,
                teacher_id: currentUserEmail.split('@')[0] 
            }, (response) => {
                if (response && response.status === "started") {
                    statusDiv.innerText = `Đang quét ngầm ${classList.length} lớp! Bạn có thể làm việc khác.`;
                } else {
                    statusDiv.innerText = 'Lỗi khởi tạo tiến trình ngầm.';
                    btnAttendance.disabled = false;
                }
            });

        } catch (error) {
            statusDiv.innerText = 'Lỗi quét DOM: ' + error.message;
            btnAttendance.disabled = false;
        }
    });

    // 2. Cào Transcript (Offscreen)
    btnTranscript.addEventListener('click', () => {
        const idsText = document.getElementById('txt-student-ids').value;
        const semester = (document.getElementById('inp-transcript-semester').value || '').trim();
        const forceRecrawl = document.getElementById('chk-force-recrawl').checked;

        if (!idsText.trim()) {
            statusDiv.innerText = 'Vui lòng nhập MSSV.';
            return;
        }

        const studentIds = idsText.split(',').map(id => id.trim()).filter(id => id);
        if (studentIds.length === 0) return;

        statusDiv.innerText = `Đang khởi động tiến trình ngầm cho ${studentIds.length} SV (Kỳ: ${semester || 'Không xác định'})...`;
        btnTranscript.disabled = true;

        chrome.runtime.sendMessage({
            command: "start_transcript_crawl",
            student_ids: studentIds,
            semester: semester,
            force_recrawl: forceRecrawl
        }, (response) => {
            if (response && response.status === "processing") {
                statusDiv.innerText = `Đang chạy ngầm ${studentIds.length} SV! Bạn có thể đóng popup này.`;
            } else {
                statusDiv.innerText = 'Lỗi khởi chạy tiến trình ngầm.';
                btnTranscript.disabled = false;
            }
        });
    });

    // Lắng nghe cập nhật tiến độ từ background
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'scraping_progress') {
            statusDiv.innerText = `🔄 Đang lưu dữ liệu lớp ${request.current}/${request.total}`;
        } else if (request.action === 'scraping_completed') {
            statusDiv.innerText = `🎉 Đã hoàn tất quét dữ liệu toàn bộ lớp học!`;
            btnAttendance.disabled = false;
        } else if (request.action === 'transcript_progress') {
            statusDiv.innerText = `🔄 Đang cào Transcript: ${request.current}/${request.total} SV`;
        } else if (request.action === 'transcript_completed') {
            statusDiv.innerText = `🎉 Đã hoàn tất cào nợ môn cho ${request.total} sinh viên!`;
            btnTranscript.disabled = false;
        } else if (request.action === 'transcript_error') {
            statusDiv.innerText = `⚠️ Lỗi cào transcript: ${request.error}`;
            btnTranscript.disabled = false;
        }
    });

    // Khởi tạo
    checkLoginStatus();
});
